About Desktop Video Software
-----------------------

This software includes everything you need to set up your Blackmagic DeckLink, Intensity or Multibridge. 

What's new in Desktop Video 8.0.1
----------------------------

	* Support for DeckLink Quad

Supported devices
-----------------

	* PCI Express based DeckLink cards (older PCI based cards are NOT supported)
	* Intensity, Intensity Pro
	* Multibridge Pro, Multibridge Eclipse

Minimum system requirements
---------------------------

Basic system requirements:

	* 32 bit x86 running Linux 2.6.23 or higher
	* 64 bit x86_64 running Linux 2.6.23 or higher

NOTE: Some server models that has a separate IO-MMU on the motherboard are not 
supported.

For uncompressed capture and playback a RAID or other fast storage is
needed. It is also recommended to use a filesystem that is optimized for
large sequential I/O such as XFS.

Licensing
---------

Some applications use the QT UI framework (http://qtsoftware.com) under 
the terms of the LGPL version 2.1. The QT dynamic libraries, built from 
unmodified source are included in the package. A copy of the LGPL can be 
found in /usr/share/doc/Blackmagic/LGPL-2.1.txt. The support note at 
http://blackmagic-design.com/support/detail.asp?techID=194 provides 
further details including how to obtain the QT source.

Supported distributions
------------------------

This release has been tested on:

	* Ubuntu 8.04 Desktop
	* Ubuntu 8.10 Desktop
	* Ubuntu 9.04 Desktop/Server
	* Ubuntu 9.10, 10.04
	* Fedora Core 10/11/12 & 13 (See known issues)
	* OpenSUSE 11.1
	* CentOS 5

Several different package formats are supplied:

	* Native package (.deb) for Ubuntu and Debian based distribution.
	* Native package (.rpm) for RedHat and RedHat based distribution.
	* Native package (.rpm) for OpenSUSE and OpenSUSE based distribution.
	* Tarball for expert/custom installation (or re-packaging).

Software dependencies
---------------------

The driver package requires some additional libraries and packages including:

	* dkms
	* opengl (recommended)
	* kernel-headers (or source) (for currently running kernel)
	* gcc, make
	* glibc 2.8

All packages above are included in most modern distributions. Consult your 
distributions documentation for more information. If your distribution doesn't
include DKMS you can download it from http://linux.dell.com/dkms/.

NOTE: Fedora Core users may have to add the "updates" repo to find DKMS.

NOTE: OpenSUSE users may have to add the isv:dell repo or download DKMS manually.

Installing Desktop Video Software
----------------------------

* Ubuntu, Debian and Debian distributions
	
	Installation from Graphical User Interface
	
		Locate and double click the downloaded Debian (end with .deb) package. 
		Once the Package Installer window appears click "Install Package".

		You need to reboot your system in order to activate the driver.

	Installation from Command Line

		Locate the downloaded driver Package. At the command prompt type:

		# dpkg -i <name_of_driver_package.deb>

		If there are messages about missing dependencies ensure that 
		install those first.

		You can type:

		# modprobe blackmagic

		to load the driver once the package is installed.

* RedHat or RedHat based distributions

	Installation from Graphical User Interface 
		
		Locate and double click the downloaded RPM package (end with .rpm) package. 
		In the "Install" dialog window, click Install. You may be required to enter
		your root password to continue. Since the package is not digitally signed you
		may get a warning about a "Missing Security Signature".

		You need to reboot your system in order to activate the driver.

	Installation from Command Line

		Locate the downloaded driver Package. At the command prompt type:

			# sudo yum install --nogpgcheck <name_of_driver_package>.rpm

		Once finished you can type:

			# modprobe blackmagic

		to load the driver once the package is installed.

* OpenSUSE or OpenSUSE based distributions
	
	Installation from Graphical User Interface 
		
		Locate and double click the downloaded RPM package (end with .rpm) package. 
		In the "Install" dialog window, click Install. You may be required to enter
		your root password to continue. Since the package is not digitally signed you
		may get a warning about a "Missing Security Signature".

		You need to reboot your system in order to activate the driver.

	Installation from Command Line

		Locate the downloaded driver Package. At the command prompt type:

			# sudo zypper in <name_of_driver_package>.rpm

		Once finished you can type:

			# modprobe blackmagic

		to load the driver once the package is installed.

* Other Linux 2.6 based distributions (Experts Only)

	No native package exist to support these distributions at the time of writing. It's
	however possible to install the driver manually by downloading the tar.gz archieve.

	Before you begin, ensure that your system satisfies external dependencies listed
	in section 2. 
	
	Once the archieve is extracted follow these steps:

		# sudo cp -R <extract_dir>/usr/src/DeckLink-8.0.1/ /usr/src
		
		# sudo cp <extract_dir>/usr/bin/* /usr/bin
		
		# sudo cp <extract_dir>/etc/init.d/* /etc/init.d
		
		# sudo cp <extract_dir>/etc/udev/rules.d/* /etc/udev/rules.d/
		
		# sudo mkdir -p /usr/lib/blackmagic
		
		# sudo cp <extract_dir>/usr/lib/blackmagic* /usr/lib/blackmagic
		
		# sudo cp <extract_dir>/etc/xdg/autostart/* /etc/xdg/autostart/
		
		# sudo ldconfig

	There are two ways of installing the driver onto your system, manually or via DKMS.
	By using DKMS the driver will be automatically be updated for you when you upgrade to
	a new kernel. If your distribution doesn't include the 'dkms' package, you can obtain it
	free from the following website: http://linux.dell.com/dkms/.

	In either case ensure that you have the kernel header files installed for your current
	kernel. Check for the directory /lib/modules/$(uname -r)/build/.

	For installing the driver using DKMS do:

		# dkms add -m DeckLink -v 8.0.1

		# dkms build -m DeckLink -v 8.0.1
		
		# dkms install -m DeckLink -v 8.0.1

	To activate driver once installed:

		# modprobe blackmagic
	
	Or installing the driver manually:

		# cd /usr/src/DeckLink-8.0.1
		# make

		If there is any compillation errors, please check that you are running a Linux 
		2.6 kernel with version 2.6.23 or higher. If you still have problems 
		please contact us.

			# sudo cp blackmagic.ko /lib/modules/$(uname -r)/kernel/drivers
			# sudo depmod -a

		Reboot your system or:

			# sudo modprobe blackmagic

		To active the driver once installed.

Frequently Asked Questions
--------------------------

* How do I check that the driver/card was loaded successfully?
		
	You can check that your computer find your PCI card by entering the
	following from a terminal:

		# lspci | grep Blackmagic
		02:00.0 Multimedia video controller: Blackmagic Design Device a11b
		
	You should see entries like the above if the card was recognized by the system.

	To test if the driver is loaded properly, type:

		# lsmod |grep blackmagic
		blackmagic                   2082944  1

	If you get no output, that means that the driver is not loaded.
		
	Also check that the device file: /dev/blackmagic/card0 is present. If it
	is not, and the driver appears to be loaded, the UDEV rule
	(/etc/udev/rules.d/20-blackmagic.rules) may not be installed properly.

* The TestPattern application does not output anything?
		
	Make sure the installed driver's firmware version matches that of
	your cards firmware. See section 3.3 for details.

* How do I update a cards firmware version?

	Installation from Graphical User Interface

		If the Driver package was installed correctly, the firmware 
		update utility should popup automatically when a card needs 
		its firmware updated.

		If not see section 3.3.2 on how to update manually.

	Installation from Command Line

		First check if your card really needs updating by issuing
		the following command from the terminal:

			# BlackmagicFirmwareUpdater status
			/dev/blackmagic/card0	[DeckLink HD Extreme 3]	UPDATED
			/dev/blackmagic/card1	[DeckLink HD Extreme 3]	NEEDS_UPDATE
		
		Cards listed with NEEDS_UPDATE can be upgraded by typing:
				
			# BlackmagicFirmwareUpdater update <card_id> (1 in this case)

		Or if runnning under an X window enviroment simply type:

			# BlackmagicFirmwareUpdater update_gui

		Which will launch the GUI firmware update tool.

* The driver crashed my system

	Look for kernel output messages in dmesg and /var/log/messages.
	
* TestPattern is flashing black every second

	This is by design to demonstrate audio/video sync.

* The RPM package installed, but the driver was not loaded.

	Try the following command:

		# dkms build -m DeckLink -v 8.0.1

	This should allow you to determine what the problem is. A common cause
	is a version mismatch between the installed kernel image, 
	and the kernel source/headers. If they do not match, simply bring either
	the source/headers or the image update to date, and reboot your system.

	Once the system is back up, the driver should be built for you at startup.

Known issues
------------

* Multiple Blackmagic PCI cards in the system on 32 bit platforms

	Multiple cards may not work very well on 32 bit platforms, due to limited
	amount of kernel space memory (from the vmalloc).
		
	Possible solutions:

	Reconfigure kernel to allow more vmalloc memory, or use 64 bit Linux
	if possible.

* Driver fails to build against certain version of linux-rt

	Some versions of the linux-rt patchset may be incompatible with the driver.

* Fedora Core 12 (and higher)

	Some PCI-e cards (1x lane cards) does not function properly 
	by default under Fedora Core 12, including DeckLink SDI and Intensity Pro.
	To work around this please add kernel boot paramter "pcie_aspm=off" to your
	bootloader (for GRUB in /boot/grub/menu.lst).

* SLES10 (2.6.16 kernel)

	Due to licensing of some symbols in the 2.6.16 kernel, the DeckLink serial
	device is not available. The serial functionality of the DeckLink devices
	is accessible through the DeckLinkDeckControl interface in the API.

* SLES10 and later driver "blacklisting"

	To start the driver at boot on SLES10 or later, the line "blacklist blackmagic"
	must be removed from /lib/modules/$(uname -r)/modules.unsupported

Additional Information
----------------------

Please check www.blackmagic-design.com for additional information on third 
party software compatibility and minimum system requirements.

� 2001-2011 Blackmagic Design Pty. Ltd. All rights reserved. Blackmagic Design, Blackmagic, DeckLink, Multibridge, Intensity, H.264 Pro Recorder and "Leading the creative video revolution" are trademarks of Blackmagic Design Pty. Ltd., registered in the U.S.A and other countries. Adobe Premiere Pro, Adobe After Effects and Adobe Photoshop are registered trademarks of Adobe Systems.


Some applications use the QT UI framework (http://qtsoftware.com) under the terms of the LGPL version 2.1. The QT dynamic libraries, built from unmodified source are included in the application bundle. A copy of the LGPL is included in the Blackmagic application support directory.  The support note at http://blackmagic-design.com/support/detail.asp?techID=194 provides further details including how to obtain the QT source.
